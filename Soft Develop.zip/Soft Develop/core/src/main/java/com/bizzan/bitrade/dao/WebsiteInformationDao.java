package com.bizzan.bitrade.dao;

import com.bizzan.bitrade.dao.base.BaseDao;
import com.bizzan.bitrade.entity.WebsiteInformation;

/**
 * @author GS
 * @description
 * @date 2018/1/25 18:22
 */
public interface WebsiteInformationDao extends BaseDao<WebsiteInformation> {
}
