package com.bizzan.bitrade.ability;

/**
 * @author GS
 * @Title: ${file_name}
 * @Description:
 * @date 2018/4/2417:35
 */
public interface CreateAbility<T> {
    //创建能力
    T transformation();
}
