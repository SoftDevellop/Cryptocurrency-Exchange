package com.bizzan.bitrade.exception;

/**
 * @author GS
 * @date 2018年03月16日
 */
public class GeeTestException extends Exception {
    public GeeTestException(String msg) {
        super(msg);
    }
}
