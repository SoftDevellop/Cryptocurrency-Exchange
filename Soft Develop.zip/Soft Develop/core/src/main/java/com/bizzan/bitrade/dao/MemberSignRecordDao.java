package com.bizzan.bitrade.dao;

import com.bizzan.bitrade.dao.base.BaseDao;
import com.bizzan.bitrade.entity.MemberSignRecord;

/**
 * @author GS
 * @Description:
 * @date 2018/5/410:18
 */
public interface MemberSignRecordDao extends BaseDao<MemberSignRecord> {
}
