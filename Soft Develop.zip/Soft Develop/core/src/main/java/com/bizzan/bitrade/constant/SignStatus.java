package com.bizzan.bitrade.constant;

/**
 * @author GS
 * @Description:
 * @date 2018/5/311:33
 */
public enum SignStatus {
    UNDERWAY, FINISH;
}
