package com.bizzan.bitrade.dao;

import com.bizzan.bitrade.dao.base.BaseDao;
import com.bizzan.bitrade.entity.Feedback;

/**
 * @author GS
 * @date 2018年03月19日
 */
public interface FeedbackDao extends BaseDao<Feedback> {
}
