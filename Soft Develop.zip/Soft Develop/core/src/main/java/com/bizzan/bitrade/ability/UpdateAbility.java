package com.bizzan.bitrade.ability;

/**
 * @author GS
 * @Title: ${file_name}
 * @Description:
 * @date 2018/4/2417:36
 */
public interface UpdateAbility<T> {
    T transformation(T t);
}
