package com.bizzan.bitrade.service;

import org.springframework.stereotype.Service;

import com.bizzan.bitrade.dao.MemberLogDao;
import com.bizzan.bitrade.entity.MemberLog;
import com.bizzan.bitrade.service.Base.TopBaseService;

@Service
public class MemberLogService  {
}
