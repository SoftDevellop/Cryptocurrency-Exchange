package com.bizzan.bitrade.model.screen;

import lombok.Data;

@Data
public class MemberDepositScreen extends AccountScreen{

    private String address ;

    private String unit ;
}
